"""
Group Action Package

This package provides tools for handling group actions.
"""

__version__ = "0.2.13"

from os import cpu_count
__num_of_cores__ = cpu_count()
